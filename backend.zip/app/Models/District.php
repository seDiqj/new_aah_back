<?php

namespace App\Models;

use App\Models\BaseModel;

class District extends BaseModel
{
    protected $fillable = [
        "name",
    ];
}
