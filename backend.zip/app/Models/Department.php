<?php

namespace App\Models;

class Department extends BaseModel
{

    protected $fillable = [
        "name",
        "status"
    ];
}
