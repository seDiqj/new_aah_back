<?php 

namespace config\system;

return [

    "NO_RECORDS_STATUS" => 200,

];